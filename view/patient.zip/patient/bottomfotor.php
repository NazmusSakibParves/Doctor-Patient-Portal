<?php include_once('session-active.php'); ?>
<style type="text/css">
	.hrtitle{
		border: 1px solid blue;
		padding: 12px;
		border-radius: 5px;
		color: #fff;
		background-image: url(img/pic3.jpg);
	}
</style>

<br/><br/>
	<div align="center">
		<label class="hrtitle">&copy;2015-2016 | Doctor Patient Portal | American International University-Bangladesh(AIUB) | All right reserved</label>
		<br/><br/>
	</div>