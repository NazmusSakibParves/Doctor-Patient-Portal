 <?php
           $nameError=$usernameError=$passwordError=$re_passwordError=$emailError=$addressError=$contactError= "";
      $name=$username=$password=$re_password=$email=$address=$contact= "";
      
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              $name = $_POST['name'];
              $user_name = $_POST['username'];
              $password = $_POST['password'];
              $gender = $_POST['gender'];
              $email = $_POST['email'];
              $blood_group = isset($_POST['bloodgroup']);
              $address = $_POST['address'];
              $contact_no = $_POST['contact'];
              $confirm_password = $_POST['re_password'];

        if(!empty($name) && !empty($user_name) && !empty($password) && !empty($confirm_password) && !empty($email) && !empty($address) && !empty($contact_no)){

                add_patients($name, $user_name, $password, $gender, $email, $blood_group, $address, $contact_no);

                echo '<div><label style="color:green">Registration complete</label> </div>';
              }
              else{
                echo '<div><label style="color:red"> Fill all the field</label> </div>';
              }

        if (empty($_POST["name"])) {
                    $nameError = "Name is Required !";
                    } 
          else {
                         $name = test_input($_POST["name"]);
                      // check if name only contains letters and whitespace
                             if (!preg_match("/^[a-zA-Z .]*$/",$name)) {
                              $nameError = "Only letters,dot and whitespace are allowed !"; 
                        }
                     }
           
    if (empty($_POST["username"])) {
                    $usernameError = "UserName is Required !";
                    } 
          else {
                         $username = test_input($_POST["username"]);
                      
                             if (!preg_match("/^[a-zA-Z\d]*$/",$username)) {
               $usernameError = "Only letters and number is allowed as a UserName!";
                        }
                     }
           
           
        if(empty($_POST["password"])){
           $passwordError = "Password is Required !";
        }
          else{
          $password = test_input($_POST["password"]);
           if (strlen($_POST["password"]) <= '4') {
            $passwordError = "Your Password Must Contain At Least 4 Characters!";
          }
           elseif(!preg_match("#[0-9]+#",$password)) {
             $passwordError = "Your Password Must Contain At Least 1 Number!";
          }
             elseif(!preg_match("#[A-Z]+#",$password)) {
             $passwordError = "Your Password Must Contain At Least 1 Capital Letter!";
            }
          elseif(!preg_match("#[a-z]+#",$password)) {
             $passwordError = "Your Password Must Contain At Least 1 Lowercase Letter!";
            }
          }
        
      
    if(empty($_POST["re_password"])){
                       $re_passwordError = "Re-Type your Password !";
    }
      else{
                         $re_password = test_input($_POST["re_password"]);
                if (!($_POST["password"] == $_POST["re_password"])) {
                       $re_passwordError = "Your Password does not match !";
                }
            }
    
    
    if(empty($_POST["email"])){
      $emailError = "E-mail is Required !";
    }else{
      $email = test_input($_POST["email"]);
      
                    // First, we check that there's one @ symbol, and that the lengths are right
               if (!preg_match("/^([a-z0-9])+([a-z0-9\._-])*@([a-z])+([a-z.]+)+$/", $email)) {
          $emailError = "Invalid Email Format !";
                }
    }
    
        if (empty($_POST["address"])) {
                $addressError = "Address is Required !";
                } 
          else {
                      $address = test_input($_POST["address"]);
                             if (strlen($_POST["address"]) >= '20') {
               $addressError = "Your Address is too long, its contains maximum 20 characters !";
                        }
                     }
           

        if(empty($_POST["contact"])){
       $contactError = "Contact is Required !";
        }
         else {
         $contact = test_input($_POST["contact"]);
         if(!preg_match("/^[0-9]{11}$/", $contact)){
           $contactError = "Invalid Contact Number Format !";
        }
        
       }
      
        
        
        

            }
  function test_input($data) {
    $data = trim($data);
    return $data;
    }

          ?>
