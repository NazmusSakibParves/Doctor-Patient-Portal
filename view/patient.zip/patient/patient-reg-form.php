
<?php include("../../service/patient_service.php");?>
<title>Registration form</title>
<style>
body{
  /*background-color: #eee;*/
  background-image: url(img/pic.png);
}
input[type=text], select {
    width: 35%;
    padding: 8px 10px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
}
input[type=password] {
    width: 35%;
    padding: 8px 10px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 4px;
}

input[type=submit] {
    width: 20%;
    background-color: #4CAF50;
    color: white;
    padding: 10px 10px;
    margin: 8px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-left: 160px;
}

input[type=submit]:hover {
    background-color: #45a049;
}
#back{
    text-decoration: none;
    border:1px solid gold;
    padding: 8px;
    color: #fff;
    border-radius: 4px;
}
#back:hover{
    background-color: #4CAF50;
    color: #fff;
    border:1px solid #4CAF50;
    padding: 8px;
    border-radius: 4px;
}

div #regdiv{
  
    border-radius: 4px;
    /*background-image: url(img/pic.png);*/
    padding: 20px;
    margin-left: 0px;
}
  #title_under{
    width: 400px;
  }
.hrtitle{
    border: 1px solid gold;
    padding: 12px;
    border-radius: 5px;
    color: #fff;
    /*background-image: url(img/pic3.jpg);*/
  }
  label{
    color: #fff;
  }
</style>
<style type="text/css">
  .pform{
      /*border: 1px solid green;
      border-radius: 5px;*/
      padding: 20px;
      width: 700px;
  }
</style>

  <div id="main" align="center">
     <div id="regdiv" align=center>
        <div align="center">
          <h3 style="color:#fff;margin-top:0">REGISTRATION FORM</h3>
          <div id="title_under">
            <hr/>
          </div>
          
        </div>
        <div align="center" style="margin-left:250px">
              <label style="color:red">* </label>
              <label style="color:gold">indicates required</label>
            </div>

          <?php
            if($_SERVER['REQUEST_METHOD'] == 'POST'){
              $name=$_POST['name'];
              $user_name=$_POST['username'];
              $password=$_POST['password'];
              $gender=$_POST['gender'];
              $email=$_POST['email'];
              $blood_group=$_POST['bloodgroup'];
              $address=$_POST['address'];
              $contact_no=$_POST['contact'];
              $confirm_password=$_POST['re_password'];

              if(!empty($name) && !empty($user_name) && !empty($password) && !empty($confirm_password) && !empty($email) && !empty($address) && !empty($contact_no)){

                add_patients($name, $user_name, $password, $gender, $email, $blood_group, $address, $contact_no);

                echo '<div><label style="color:green">Registration complete</label> </div>';
              }
              else{
                echo '<div><label style="color:red"> Fill all the fields</label> </div>';
              }

            }



              //test method 
               function test_input($data) {
                   $data = trim($data);
                   return $data;
              }

          ?>

            

        
      <form method="post" action="patient-reg-form.php">
      
        <div class="pform">
        <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        Name<span style="color:red">*</span></label>
        <input type="text" id="fname" name="name" placeholder="enter name"><br/>

        <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        Username<span style="color:red">*</span></label>
        <input type="text" id="username" name="username" placeholder="username"><br/>

        <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        Password<span style="color:red">*</span></label>
        <input type="password" id="password" name="password" placeholder="password"><br/>

        <label style="left:50px">Confirm-Password<span style="color:red">*</span></label>
        <input type="password" id="re_password" name="re_password" placeholder="confirm-password"><br/>

        <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        Gender</label>
        <select id="gender" name="gender">
           <option value="Male">Male</option>
           <option value="Female">Female</option>
          </select><br/>

          <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;E-mail Address<span style="color:red">*</span></label>
        <input type="text" id="email" name="email" placeholder="e-mail address"><br/>

        <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        Blood Group</label>
        <select id="bloodgroup" name="bloodgroup">
           <option>AB+</option>
           <option>AB-</option> 
           <option>B+</option>
           <option>A+</option>
           <option>O+</option>
           <option>B-</option>
           <option>A-</option>
           <option>O-</option>
          </select><br/>

          <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Address<span style="color:red">*</span></label>
        <input type="text" id="address" name="address" placeholder="address"><br/>

        
        <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Contact Number<span style="color:red">*</span></label>
        <input type="text" id="contact" name="contact" placeholder="contact number"><br/>

        <br/>
          <input type="submit" id="submitbtn" value="Apply">
        
        </div>
      </form>
      <div align="center">
        <a id="back" href=" ../index.php">Back to login page</a>
      </div>
      
  </div>



<!--Bottom options -->
<br/><br/>
  <div align="center">
    <label class="hrtitle">&copy;2015-2016 | Doctor Patient Portal | American International University-Bangladesh(AIUB) | All right reserved</label>
    <br/><br/>
  </div>