<!--dashboard options -->
<?php include("patientdashboard.php");?>

<hr/>
  
   <div id="main" align="center">
        <div id="Registration">
       		<h3 style="color:blue;">DOCTOR'S LIST</h3>
      	 	<hr style="color:red" />
    	</div>

    </div>



<!--Bottom options -->
<?php include("bottomfotor.php");?>