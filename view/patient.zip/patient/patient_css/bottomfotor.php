<!--<link rel="stylesheet" type="text/css" href="../css/bottomoption.css">-->
<style type="text/css">
	.bottomoption{
		background-color: #eee;
		text-align: center;
	}
	div.left {
	background-color: #22868E;
	float: left;
	width: 40%;
	height: 180px;
	padding: 5px;
	text-align: center;
	table-layout: inherit;
	text-decoration: none;
}
div.right {
	background-color: #22868E;
	float: right;
	width: 57%;
	height: 180px;
	padding: 5px;
	text-align: center;
	color: gold;
}
.content{
	color: blue;
	padding: 4px;
}
.leftancor{
	color: #fff;
}
.leftancor:hover{
	color: gold;
	text-decoration: underline;
}
</style>

<div class="bottomoption">
		<p class="content">
			CONTENT
			<hr class="belowcontent" />
		</p>

	
		<div class="left">
			<div id="socialtitle">
			<label style="color:gold;">SOCIAL MEDIA</label>
			</div>
			<br/>
			<table align="center">
				<tr>
					<td>
						<img src="img/fb.png" alt="logo"/> 
					</td>
					<td>
						<a class="leftancor" target="_blank" href="https://www.facebook.com/">facebook</a>
					</td>
				</tr>
				<tr>
					<td>
						<img src="img/twiter.png" alt="logo"/> 
					</td>
					<td>
						<a class="leftancor" target="_blank" href="https://twitter.com/?lang=en">twiter</a>
					</td>
				</tr>
				<tr>
					<td>
						<img src="img/in.png" alt="logo"/> 
					</td>
					<td>
						<a class="leftancor" target="_blank" href="https://www.linkedin.com/">linkedin</a>
					</td>
				</tr>
			</table>

		</div>
		<div class="right">
			<diV>
				<label style="color:#fff;">ABOUT</label>
			</div>
			<div>
				<p class="aboutclass">
					Efficient Doctor & Patient Portal<br/>
					American International University-Bangladesh(AIUB)<br/>
					Email | faisal.porag@yahoo.com | nazmussakib.parves69@gmail.com <br/>
					Emial | shamsulhuda@gmail.com  | newajshahriar@gmail.com <br/>
					&copy; 2015-2016 | Efficient doctor patient portal | All right reserved
					<hr/>
				</p>
			</div>
			<br/><br/>
		</div>
		
	
</div>