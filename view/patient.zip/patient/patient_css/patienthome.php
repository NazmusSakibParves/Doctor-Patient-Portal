<!--dashboard options -->
<?php include("patientdashboard.php");?>
	
	<hr/>
	<label align="center" >Welcome Patient</label>


<!--Bottom options -->
<?php include("bottomfotor.php");?>