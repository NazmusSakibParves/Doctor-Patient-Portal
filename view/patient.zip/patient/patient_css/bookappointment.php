<?php include("patientdashboard.php");?>

 <hr/>
  
   <div id="main" align="center">
      <div id="Registration">
       <h3 style="color:blue;">BOOK APPOINTMENT</h3>
       <hr style="color:red" />
       </div>
     </div>
	 
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	 
	 <!--Bottom options -->
<?php include("bottomfotor.php");?>